import os
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    SetEnvironmentVariable,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, Command, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    articubot_pkg = 'articubot_one'
    moveit_pkg = 'k12_moveit_config'
    pick_place_pkg = 'k12_pick_place'

    gui_arg = DeclareLaunchArgument(
        'gui', default_value='true',
        description='Start Gazebo client if true',
    )
    run_sequence_arg = DeclareLaunchArgument(
        'run_sequence', default_value='true',
        description='Start the MoveIt pick-place commander if true',
    )
    spawn_objects_arg = DeclareLaunchArgument(
        'spawn_test_objects', default_value='true',
        description='Spawn the graspable test objects if true',
    )
    world_arg = DeclareLaunchArgument(
        'world',
        default_value=PathJoinSubstitution([
            FindPackageShare(articubot_pkg), 'worlds', 'og.world',
        ]),
        description='Full path to the Gazebo world file',
    )

    config_file = PathJoinSubstitution([
        FindPackageShare(pick_place_pkg), 'config', 'moveit_pick_place_standalone.yaml',
    ])

    xacro_file = os.path.join(
        get_package_share_directory(articubot_pkg), 'description', 'four_wheel.xacro'
    )
    robot_description = ParameterValue(
        Command(['xacro ', xacro_file, ' use_ros2_control:=true', ' sim_mode:=true']),
        value_type=str,
    )

    moveit_config_dir = os.path.join(get_package_share_directory(moveit_pkg), 'config')
    srdf_file = os.path.join(moveit_config_dir, 'k12.srdf')
    with open(srdf_file, 'r') as f:
        robot_description_semantic = f.read()

    move_group_params = {
        'robot_description_kinematics': {
            'arm': {
                'kinematics_solver': 'kdl_kinematics_plugin/KDLKinematicsPlugin',
                'kinematics_solver_search_resolution': 0.005,
                'kinematics_solver_timeout': 0.05,
                'position_only_ik': True,
            },
        },
        'robot_description_planning': {
            'joint_limits': {
                'arm_base_yaw_joint': {'has_velocity_limits': True, 'max_velocity': 2.0, 'has_acceleration_limits': True, 'max_acceleration': 5.0},
                'arm_shoulder_pitch_joint': {'has_velocity_limits': True, 'max_velocity': 2.0, 'has_acceleration_limits': True, 'max_acceleration': 5.0},
                'arm_elbow_pitch_joint': {'has_velocity_limits': True, 'max_velocity': 2.0, 'has_acceleration_limits': True, 'max_acceleration': 5.0},
                'arm_wrist_pitch_joint': {'has_velocity_limits': True, 'max_velocity': 2.0, 'has_acceleration_limits': True, 'max_acceleration': 5.0},
                'arm_wrist_roll_joint': {'has_velocity_limits': True, 'max_velocity': 2.0, 'has_acceleration_limits': True, 'max_acceleration': 5.0},
            },
        },
        'planning_pipelines': ['ompl'],
        'default_planning_pipeline': 'ompl',
        'ompl': {
            'planning_plugin': 'ompl_interface/OMPLPlanner',
            'start_state_max_bounds_error': 0.1,
            'jiggle_fraction': 0.05,
            'request_adapters': (
                'default_planner_request_adapters/AddTimeOptimalParameterization '
                'default_planner_request_adapters/ResolveConstraintFrames '
                'default_planner_request_adapters/FixWorkspaceBounds '
                'default_planner_request_adapters/FixStartStateBounds '
                'default_planner_request_adapters/FixStartStateCollision '
                'default_planner_request_adapters/FixStartStatePathConstraints'
            ),
            'enforce_joint_model_state_space': True,
            'projection_evaluator': 'joints(arm_base_yaw_joint,arm_shoulder_pitch_joint,arm_elbow_pitch_joint)',
            'planner_configs': {
                'RRTConnect': {'type': 'geometric::RRTConnect', 'range': 0.0},
                'RRT': {'type': 'geometric::RRT', 'range': 0.0, 'goal_bias': 0.05},
                'RRTstar': {'type': 'geometric::RRTstar', 'range': 0.0, 'goal_bias': 0.05, 'delay_collision_checking': True},
                'PRM': {'type': 'geometric::PRM', 'max_nearest_neighbors': 10},
                'PRMstar': {'type': 'geometric::PRMstar'},
            },
        },
        'moveit_controller_manager': 'moveit_simple_controller_manager/MoveItSimpleControllerManager',
        'moveit_simple_controller_manager': {
            'controller_names': ['arm_position_controller'],
            'arm_position_controller': {
                'type': 'FollowJointTrajectory',
                'action_ns': 'follow_joint_trajectory',
                'default': True,
                'joints': [
                    'arm_base_yaw_joint', 'arm_shoulder_pitch_joint',
                    'arm_elbow_pitch_joint', 'arm_wrist_pitch_joint', 'arm_wrist_roll_joint',
                ],
            },
        },
        'publish_planning_scene': True,
        'publish_geometry_updates': True,
        'publish_state_updates': True,
        'publish_transforms_updates': True,
        'moveit_manage_controllers': True,
        'use_sim_time': True,
    }

    amms_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare(articubot_pkg), 'launch', 'amms_gazebo.launch.py',
            ])
        ]),
        launch_arguments={
            'gui': LaunchConfiguration('gui'),
            'world': LaunchConfiguration('world'),
            'use_arm_ros2_control': 'true',
            'spawn_arm_controllers': 'true',
            'verbose': 'true',
        }.items(),
    )

    scene_spawner = Node(
        package=pick_place_pkg, executable='scene_spawner',
        name='amms_scene_spawner',
        condition=IfCondition(LaunchConfiguration('spawn_test_objects')),
        parameters=[{
            'spawn_tables': True,
            'spawn_objects': ParameterValue(
                LaunchConfiguration('spawn_test_objects'), value_type=bool,
            ),
            'pickup_table_position': [0.55, 0.0, 0.0],
        }],
        output='screen',
    )

    detector = Node(
        package=pick_place_pkg, executable='object_detector',
        name='k12_object_detector',
        parameters=[config_file],
        output='screen',
    )

    move_group_node = Node(
        package='moveit_ros_move_group',
        executable='move_group',
        output='screen',
        parameters=[
            {'robot_description': robot_description},
            {'robot_description_semantic': robot_description_semantic},
            move_group_params,
        ],
    )

    commander = Node(
        package=pick_place_pkg, executable='moveit_pick_place_commander',
        name='moveit_pick_place_commander',
        condition=IfCondition(LaunchConfiguration('run_sequence')),
        parameters=[config_file],
        output='screen',
    )

    rviz_config = os.path.join(moveit_config_dir, 'moveit.rviz')
    rviz_node = Node(
        package='rviz2', executable='rviz2', name='rviz2',
        output='screen',
        arguments=['-d', rviz_config],
        parameters=[{
            'robot_description': robot_description,
            'robot_description_semantic': robot_description_semantic,
            'use_sim_time': True,
        }],
    )

    return LaunchDescription([
        SetEnvironmentVariable('GAZEBO_MODEL_DATABASE_URI', ''),
        gui_arg,
        run_sequence_arg,
        spawn_objects_arg,
        world_arg,
        amms_launch,
        scene_spawner,
        detector,
        TimerAction(period=15.0, actions=[move_group_node]),
        TimerAction(period=18.0, actions=[commander]),
        TimerAction(period=20.0, actions=[rviz_node]),
    ])
