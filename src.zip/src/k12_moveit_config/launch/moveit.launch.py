import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    articubot_pkg = 'articubot_one'
    moveit_pkg = 'k12_moveit_config'

    use_sim_time = LaunchConfiguration('use_sim_time')
    use_rviz = LaunchConfiguration('use_rviz')

    use_sim_time_arg = DeclareLaunchArgument('use_sim_time', default_value='true')
    use_rviz_arg = DeclareLaunchArgument('use_rviz', default_value='true')

    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(
                get_package_share_directory(articubot_pkg),
                'launch', 'amms_gazebo.launch.py',
            )
        ]),
        launch_arguments={
            'use_sim_time': use_sim_time,
            'gui': 'true',
            'spawn_arm_controllers': 'true',
        }.items(),
    )

    xacro_file = os.path.join(
        get_package_share_directory(articubot_pkg), 'description', 'four_wheel.xacro'
    )
    robot_description = ParameterValue(
        Command(['xacro ', xacro_file,
                 ' use_ros2_control:=true',
                 ' sim_mode:=true']),
        value_type=str,
    )

    moveit_config_dir = os.path.join(
        get_package_share_directory(moveit_pkg), 'config'
    )

    srdf_file = os.path.join(moveit_config_dir, 'k12.srdf')
    with open(srdf_file, 'r') as f:
        robot_description_semantic = f.read()

    # Structure matching MoveItConfigsBuilder.to_dict():
    # planning_pipelines is a LIST, ompl config is flat at top level,
    # controller params are flat at top level.
    move_group_params = {
        # Kinematics
        'robot_description_kinematics': {
            'arm': {
                'kinematics_solver': 'kdl_kinematics_plugin/KDLKinematicsPlugin',
                'kinematics_solver_search_resolution': 0.005,
                'kinematics_solver_timeout': 0.05,
                'position_only_ik': False,
            },
        },
        # Planning (robot_description_planning contains joint_limits)
        'robot_description_planning': {
            'joint_limits': {
                'arm_base_yaw_joint': {
                    'has_velocity_limits': True, 'max_velocity': 2.0,
                    'has_acceleration_limits': True, 'max_acceleration': 5.0,
                },
                'arm_shoulder_pitch_joint': {
                    'has_velocity_limits': True, 'max_velocity': 2.0,
                    'has_acceleration_limits': True, 'max_acceleration': 5.0,
                },
                'arm_elbow_pitch_joint': {
                    'has_velocity_limits': True, 'max_velocity': 2.0,
                    'has_acceleration_limits': True, 'max_acceleration': 5.0,
                },
                'arm_wrist_pitch_joint': {
                    'has_velocity_limits': True, 'max_velocity': 2.0,
                    'has_acceleration_limits': True, 'max_acceleration': 5.0,
                },
                'arm_wrist_roll_joint': {
                    'has_velocity_limits': True, 'max_velocity': 2.0,
                    'has_acceleration_limits': True, 'max_acceleration': 5.0,
                },
            },
        },
        # Planning pipelines - flat structure matching MoveItConfigsBuilder
        'planning_pipelines': ['ompl'],
        'default_planning_pipeline': 'ompl',
        'ompl': {
            'planning_plugin': 'ompl_interface/OMPLPlanner',
            'start_state_max_bounds_error': 0.1,
            'jiggle_fraction': 0.05,
            'request_adapters': (
                'default_planner_request_adapters/AddTimeOptimalParameterization '
                'default_planner_request_adapters/ResolveConstraintFrames '
                'default_planner_request_adapters/FixWorkspaceBounds '
                'default_planner_request_adapters/FixStartStateBounds '
                'default_planner_request_adapters/FixStartStateCollision '
                'default_planner_request_adapters/FixStartStatePathConstraints'
            ),
            'enforce_joint_model_state_space': True,
            'projection_evaluator': 'joints(arm_base_yaw_joint,arm_shoulder_pitch_joint,arm_elbow_pitch_joint)',
            'planner_configs': {
                'RRTConnect': {'type': 'geometric::RRTConnect', 'range': 0.0},
                'RRT': {'type': 'geometric::RRT', 'range': 0.0, 'goal_bias': 0.05},
                'RRTstar': {'type': 'geometric::RRTstar', 'range': 0.0, 'goal_bias': 0.05, 'delay_collision_checking': True},
                'PRM': {'type': 'geometric::PRM', 'max_nearest_neighbors': 10},
                'PRMstar': {'type': 'geometric::PRMstar'},
            },
        },
        # Controller manager - params go under moveit_simple_controller_manager namespace
        'moveit_controller_manager': 'moveit_simple_controller_manager/MoveItSimpleControllerManager',
        'moveit_simple_controller_manager': {
            'controller_names': ['arm_position_controller'],
            'arm_position_controller': {
                'type': 'FollowJointTrajectory',
                'action_ns': 'follow_joint_trajectory',
                'default': True,
                'joints': [
                    'arm_base_yaw_joint',
                    'arm_shoulder_pitch_joint',
                    'arm_elbow_pitch_joint',
                    'arm_wrist_pitch_joint',
                    'arm_wrist_roll_joint',
                ],
            },
        },
        # MoveGroup settings
        'publish_planning_scene': True,
        'publish_geometry_updates': True,
        'publish_state_updates': True,
        'publish_transforms_updates': True,
        'moveit_manage_controllers': True,
        'use_sim_time': True,
    }

    move_group_node = Node(
        package='moveit_ros_move_group',
        executable='move_group',
        output='screen',
        parameters=[
            {'robot_description': robot_description},
            {'robot_description_semantic': robot_description_semantic},
            move_group_params,
        ],
    )

    rviz_config = os.path.join(moveit_config_dir, 'moveit.rviz')
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config],
        condition=IfCondition(use_rviz),
        parameters=[{
            'robot_description': robot_description,
            'robot_description_semantic': robot_description_semantic,
            'use_sim_time': use_sim_time,
        }],
    )

    return LaunchDescription([
        use_sim_time_arg,
        use_rviz_arg,
        gazebo_launch,
        TimerAction(period=8.0, actions=[move_group_node]),
        TimerAction(period=10.0, actions=[rviz_node]),
    ])
